/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.comercesystem;

/**
 *
 * @author Victus
 */
public class Cart {

    
    
    private int customerId;
    private int nProducts;
    private product[] products;

    public Cart(int customerId, int nProducts) {
        this.customerId =Math.abs(customerId);
        this.nProducts = Math.abs(nProducts);
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = Math.abs(customerId);
    }

    public int getnProducts() {
        return nProducts;
    }

    public void setnProducts(int nProducts) {
        this.nProducts = Math.abs(nProducts);
         this.products = new product [nProducts];
    }

    

    public void setProducts(product[] products) {
        this.products = new product[nProducts];
    }

    public void addProduct(product prod , int i) {
            products[i] = prod;
            System.out.println(products[i].getName() + " was added ");         
     }

    public void removeProduct(int a) {
        if (a>=0){
      this.products[a] = null ;
        }
    }

    public float calculatePrice() {
        float price = 0;
        for (product i : products) {
            if (i != null){
            price += i.getPrice();
        }
        }
        return price;
    }
    
    public void placeOrder(){
        System.out.println("Your ID : "+customerId);
        System.out.println("Total Price : "+Cart.this.calculatePrice());
        for (int i =0 ;i<products.length;i++) {
            System.out.println(products[i].getName() + " - $" + products[i].getPrice());
        }

    }
    public void getproducts (){
     for (product x : products ){
        System.out.println(x.getName()+" - "+x.getPrice());
        }
    }
}
