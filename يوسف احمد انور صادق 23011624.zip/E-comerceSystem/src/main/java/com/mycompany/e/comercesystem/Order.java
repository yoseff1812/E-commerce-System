/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.comercesystem;

/**
 *
 * @author Victus
 */
public class Order {

    private int customerId;
    private int orderId;
    private product products[];
    private float totalPrice;

    public Order() {
    }

    public Order(int customerId, int orderId, product[] products, float totalPrice) {
        this.customerId = customerId;
        this.orderId = orderId;
        this.products = products;
        this.totalPrice = totalPrice;
    }

    public void printOrderInfo() {
        System.out.println("Customer ID : " + customerId);
        System.out.println("Order ID : " + orderId);
        System.out.println("Products : ");
        System.out.println("Total Price : " + totalPrice);
    }

}
