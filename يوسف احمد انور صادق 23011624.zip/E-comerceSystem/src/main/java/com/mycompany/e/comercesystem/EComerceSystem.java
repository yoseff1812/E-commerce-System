/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.e.comercesystem;

import java.util.Scanner;

/**
 *
 * @author Victus
 */
public class EComerceSystem {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Welcome to the Ecommerce Sysyem !");
        ElectronicProduct e1 = new ElectronicProduct(1, "Smart Phone", 599.99f, "Samsung", 1);
        ClothingProduct c1 = new ClothingProduct(2, "T-Shirt", 19.99f, "miduame", "Cotton");
        BookProduct b1 = new BookProduct("O’Reilly", "X Publications", 3, "OOP", 39.99f);
        System.out.print("Please Enter your ID : ");
        int id = in.nextInt();
        System.out.print("Please Enter your Name : ");
        String name = in.next();
        System.out.print("Please Enter your address : ");
        String address = in.next();
        Customer C = new Customer(id, name, address);
        System.out.println("How many products you want to add to your cart ? ");
        int n = in.nextInt();
        Cart j = new Cart(id, n);
        j.setnProducts(n);
        for (int i = 0; i < n; i++) {
            System.out.println("Which Product you want to add yo your Cart ? \n 1.Smart Phone \n 2.T-Shirt \n 3.OOP");

            int c = in.nextInt();
            switch (c) {
                case 1:
                    j.addProduct(e1, i);
                    break;
                case 2:
                    j.addProduct(c1, i);
                    break;
                case 3:
                    j.addProduct(b1, i);
                    break;
                default:
                    System.out.println("Invaild Choice Please Choose again");
                    i--;
                    break;
            }
        }

        System.out.println("Your Total Salary : " + j.calculatePrice() + ". Would you like to place the order \n 1.Yes \n 2.No ");
        int x = in.nextInt();
        Order o1 = new Order();
        if (x == 1) {
            System.out.println("Here's your order's summary : ");
//            o1.printOrderInfo();
            j.placeOrder();
        } else {
            System.out.println("We cancelled all your Orders ");
        }
        System.out.println("We hope we could help you Thanks.");
    }
}

