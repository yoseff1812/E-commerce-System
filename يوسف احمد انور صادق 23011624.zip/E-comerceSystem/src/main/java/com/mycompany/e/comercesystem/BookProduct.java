/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.e.comercesystem;

/**
 *
 * @author Victus
 */
public class BookProduct extends product {

    public BookProduct(String Author, String Publisher, int productId, String name, double price) {
        super(productId, name, price);
        this.Author = Author;
        this.Publisher = Publisher;
    }

   
     private String Author;
 private String Publisher;

    public String getAuthor() {
        return Author;
    }

    public String getPublisher() {
        return Publisher;
    }

    public void setAuthor(String Author) {
        this.Author = Author;
    }

    public void setPublisher(String Publisher) {
        this.Publisher = Publisher;
    }

  
}
